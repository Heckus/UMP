#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import os
import logging
from argparse import ArgumentParser
import shutil
import cv2
#from PIL import Image

# This Python script is based on the shell converter script provided in the MipNerF 360 repository.
parser = ArgumentParser("Colmap converter")
parser.add_argument("--no_gpu", action='store_true')
parser.add_argument("--skip_matching", action='store_true')
parser.add_argument("--source_path", "-s", required=True, type=str)
parser.add_argument("--images_dir", "-i", type=str, default="images")
parser.add_argument("--camera", default="OPENCV", type=str)
parser.add_argument("--colmap_executable", default="colmap", type=str)
parser.add_argument("--resize", action="store_true", default=True)
parser.add_argument("--magick_flag", action='store_true')
parser.add_argument("--magick_executable", default="", type=str)
args = parser.parse_args()
colmap_command = '"{}"'.format(args.colmap_executable) if len(args.colmap_executable) > 0 else "colmap"
magick_command = '"{}"'.format(args.magick_executable) if len(args.magick_executable) > 0 else "magick"
use_gpu = 1 if not args.no_gpu else 0

if not args.skip_matching:
    os.makedirs(args.source_path + "/distorted/sparse", exist_ok=True)

    ## Feature extraction
    feat_extracton_cmd = colmap_command + " feature_extractor "\
        "--database_path " + args.source_path + "/distorted/database.db \
        --image_path " + args.source_path + "/" + args.images_dir + " \
        --ImageReader.single_camera 1 \
        --ImageReader.camera_model " + args.camera 
    exit_code = os.system(feat_extracton_cmd)
    if exit_code != 0:
        logging.error(f"Feature extraction failed with code {exit_code}. Exiting.")
        exit(exit_code)

    ## Feature matching
    feat_matching_cmd = colmap_command + " exhaustive_matcher \
        --database_path " + args.source_path + "/distorted/database.db"
    exit_code = os.system(feat_matching_cmd)
    if exit_code != 0:
        logging.error(f"Feature matching failed with code {exit_code}. Exiting.")
        exit(exit_code)

    ### Bundle adjustment
    # The default Mapper tolerance is unnecessarily large,
    # decreasing it speeds up bundle adjustment steps.
    mapper_cmd = (colmap_command + " mapper \
        --database_path " + args.source_path + "/distorted/database.db \
        --image_path "  + args.source_path + "/" + args.images_dir + " \
        --output_path "  + args.source_path + "/distorted/sparse \
        --Mapper.ba_global_function_tolerance=0.000001")
    exit_code = os.system(mapper_cmd)
    if exit_code != 0:
        logging.error(f"Mapper failed with code {exit_code}. Exiting.")
        exit(exit_code)


img_undist_cmd = (colmap_command + " image_undistorter \
    --image_path " + args.source_path + "/" + args.images_dir + " \
    --input_path " + args.source_path + "/distorted/sparse/0 \
    --output_path " + args.source_path + "\
    --output_type COLMAP")
exit_code = os.system(img_undist_cmd)
if exit_code != 0:
    logging.error(f"Mapper failed with code {exit_code}. Exiting.")
    exit(exit_code)

files = os.listdir(args.source_path + "/sparse")
os.makedirs(args.source_path + "/sparse/0", exist_ok=True)
# Copy each file from the source directory to the destination directory
for file in files:
    if file == '0':
        continue
    source_file = os.path.join(args.source_path, "sparse", file)
    destination_file = os.path.join(args.source_path, "sparse", "0", file)
    shutil.move(source_file, destination_file)

    
def resize_and_save(destination_file, factor, magick_flag=False, magick_command="magick"):    
    def convert_to_percentage(value):
        if value < 1:
            if value == 0.125:
                return 12.5
            else:
                return int(value * 100)
        else:
            return value
    if magick_flag:
        exit_code = os.system(magick_command + f" mogrify -resize {convert_to_percentage(factor)}% " + destination_file)       
        if exit_code != 0:
            logging.error(f"50% resize failed with code {exit_code}. Exiting.")
            exit(exit_code)
    else: 
        try:
            image = cv2.imread(destination_file)
            new_width = int(image.shape[1] * factor)
            new_height = int(image.shape[0] * factor)
            new_dimensions = (new_width, new_height)
            resized_image = cv2.resize(image, new_dimensions)
            cv2.imwrite(destination_file, resized_image)
            
            # image = Image.open(destination_file)
            # resized_image = image.resize((int(image.width * factor), int(image.height * factor)))
            # resized_image.save(destination_file)
        except Exception as e:
            logging.error(f"Failed to resize image: {e}")

if(args.resize):
    print("Copying and resizing...")

    # Resize images.
    os.makedirs(args.source_path + "/images_2", exist_ok=True)
    # os.makedirs(args.source_path + "/images_4", exist_ok=True)
    # os.makedirs(args.source_path + "/images_8", exist_ok=True)
    # Get the list of files in the source directory
    files = os.listdir(args.source_path + "/images")
    # Copy each file from the source directory to the destination directory
    for file in files:
        source_file = os.path.join(args.source_path, "images", file)

        destination_file = os.path.join(args.source_path, "images_2", file)
        shutil.copy2(source_file, destination_file)
        resize_and_save(destination_file, factor=0.5, magick_flag=args.magick_flag, magick_command=magick_command)

        # destination_file = os.path.join(args.source_path, "images_4", file)
        # shutil.copy2(source_file, destination_file)
        # resize_and_save(destination_file, factor=0.25, magick_flag=args.magick_flag, magick_command=magick_command)

        # destination_file = os.path.join(args.source_path, "images_8", file)
        # shutil.copy2(source_file, destination_file)
        # resize_and_save(destination_file, factor=0.125, magick_flag=args.magick_flag, magick_command=magick_command)

print("Done.")
